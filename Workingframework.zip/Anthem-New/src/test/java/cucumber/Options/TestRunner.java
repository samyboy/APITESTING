package cucumber.Options;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/java/features",plugin="json:target/jsonReports/cucumber-report.json",glue= {"stepDefinations"})//,tags= "@BuildValidation")
public class TestRunner {

}
//Cucumber.Options(features={"File1.feature", "File3.feature","File2.feature"})