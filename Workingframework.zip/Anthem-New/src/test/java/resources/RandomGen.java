package resources;

import java.util.Random;

public class RandomGen {
	
	public static String sourceSysClaimId() {
		 Random random = new Random();   
			
		String r = String.format("%09d", random.nextInt(1000000000));
		
		return r;
		
		
		}

}
