//package resources;
//
//import pojo.AddTransaction;
//
//public class TestDataBuild {
//	
//	public AddTransaction addAccumTransaction(String accumName, String memberContract, String claimNetwork) {
//		AddTransaction addAccum = new AddTransaction();
//		addAccum.setClaimReasonText("S-D");
//		addAccum.setMemberHCId("111A40346");
//		addAccum.setTransactionPath("EA");
//		addAccum.setServiceStartDate("2015-09-09");
//		addAccum.setProviderTaxId("0");
//		addAccum.setMemberCode("70");
//		addAccum.setProviderLicenseNo("A00076108");
//		addAccum.setAccumName(accumName);
//		addAccum.setSourceSystemClaimId(RandomGen.sourceSysClaimId());	
//		addAccum.setMemberContract(memberContract);
//		addAccum.setServiceEndDate("2015-01-06");
//		addAccum.setLastUpdtUsrId("ODSINITL");
//		addAccum.setOrganizationCode("ANT");
//		addAccum.setVisits(0);
//		addAccum.setClaimSource("898");
//		addAccum.setProviderNPIId("1871538769");
//		addAccum.setMemberSource("808");
//		addAccum.setAccumStartDate("2015-01-01");
//		addAccum.setClaimId("2015");
//		addAccum.setDays(0);
//		addAccum.setMemberCase("IN");
//		addAccum.setAccumEndDate("2015-12-31");
//		addAccum.setAmount(219.66);
//		addAccum.setMemberTier("0");
//		addAccum.setProductType("MED");
//		addAccum.setDiagnosisCode("70400");
//		addAccum.setClaimNetwork(claimNetwork);
//		
//		return addAccum;
//		
//	}
//	
//}
//
